'use strict';

const API_BASE_URL = 'https://tibiaonline.klyraai.com.br/api';
const ALLOWED_ENDPOINTS = new Set([
  '/ai/telemetry',
  '/events/batch',
  '/economy/summary',
  '/health',
  '/hunts/advisor',
  '/hunt/leaderboard',
  '/hunt/record',
  '/login',
  '/register',
  '/verify',
  '/version/check'
]);
const ALLOWED_METHODS = new Set(['GET', 'POST']);
const MAX_BODY_LENGTH = 2 * 1024 * 1024;

function isAllowedSender(sender) {
  try {
    const url = new URL(sender.url || sender.tab?.url || '');
    return url.protocol === 'https:'
      && (url.hostname === 'stonegy-online.com' || url.hostname.endsWith('.stonegy-online.com'));
  } catch (e) {
    return false;
  }
}

async function handleApiRequest(message, sender) {
  if (!isAllowedSender(sender)) {
    return { ok: false, status: 403, data: { success: false, message: 'Origem não autorizada.' } };
  }

  const rawPath = String(message.endpointPath || '');
  const cleanPath = rawPath.split('?')[0];
  if (!ALLOWED_ENDPOINTS.has(cleanPath)) {
    return { ok: false, status: 403, data: { success: false, message: 'Endpoint não autorizado.' } };
  }

  const suppliedOptions = message.options && typeof message.options === 'object' ? message.options : {};
  const method = String(suppliedOptions.method || 'GET').toUpperCase();
  if (!ALLOWED_METHODS.has(method)) {
    return { ok: false, status: 405, data: { success: false, message: 'Método não autorizado.' } };
  }

  const body = typeof suppliedOptions.body === 'string' ? suppliedOptions.body : undefined;
  if (body && body.length > MAX_BODY_LENGTH) {
    return { ok: false, status: 413, data: { success: false, message: 'Requisição muito grande.' } };
  }

  const suppliedHeaders = suppliedOptions.headers && typeof suppliedOptions.headers === 'object'
    ? suppliedOptions.headers
    : {};
  const headers = {};
  for (const [name, value] of Object.entries(suppliedHeaders)) {
    const normalizedName = name.toLowerCase();
    if (normalizedName === 'content-type' || normalizedName === 'authorization') {
      headers[name] = String(value);
    }
  }

  try {
    const response = await fetch(`${API_BASE_URL}${rawPath}`, {
      method,
      headers,
      body: method === 'GET' ? undefined : body,
      cache: 'no-store'
    });
    const responseText = await response.text();
    let data = null;
    try {
      data = responseText ? JSON.parse(responseText) : null;
    } catch (e) {
      data = { success: false, message: responseText || `HTTP ${response.status}` };
    }

    return { ok: response.ok, status: response.status, data };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      data: { success: false, message: error?.message || 'Servidor inacessível no momento.' }
    };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'STONEGY_API_REQUEST') return false;
  handleApiRequest(message, sender).then(sendResponse);
  return true;
});
