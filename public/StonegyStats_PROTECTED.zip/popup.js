/**
 * Popup Script para Stonegy Pro Tracker
 */

(function () {
  const statDmg = document.getElementById('statDmg');
  const statDps = document.getElementById('statDps');
  const statKills = document.getElementById('statKills');
  const feedList = document.getElementById('feedList');
  const search = document.getElementById('search');
  const exportBtn = document.getElementById('exportBtn');

  let currentFilter = 'ALL';
  let cachedEvents = [];

  // Consulta a aba ativa do Stonegy para obter os eventos em tempo real
  function pollActiveTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].url || !tabs[0].url.includes('stonegy-online.com')) return;

      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          if (window.cmd && window.__stonegyProTrackerActive) {
            return {
              stats: window.cmd ? { dps: 0 } : null,
              history: typeof window.cmd !== 'undefined' ? true : false
            };
          }
          return null;
        }
      }, () => {});
    });
  }

  // Filtros
  const filterBtns = {
    fAll: 'ALL',
    fDamage: 'DAMAGE',
    fMonsters: 'MONSTERS',
    fWs: 'WS',
    fHttp: 'HTTP'
  };

  Object.keys(filterBtns).forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.onclick = () => {
      document.querySelectorAll('.chip').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = filterBtns[id];
    };
  });

  exportBtn.onclick = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => { if (window.cmd) window.cmd.export(); }
        });
      }
    });
  };

  setInterval(pollActiveTab, 1000);
})();
