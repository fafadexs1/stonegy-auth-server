(function () {
  'use strict';

  const CHANNEL = 'stonegy-extension-api-v1';

  function isExtensionValid() {
    try {
      if (typeof chrome === 'undefined') return false;
      const runtime = chrome.runtime;
      return !!runtime && typeof runtime.id === 'string' && runtime.id.length > 0;
    } catch (e) {
      // O contexto pode ser invalidado enquanto a extensão é recarregada.
      return false;
    }
  }

  function notifyReady() {
    if (!isExtensionValid()) return;
    try {
      window.postMessage({ channel: CHANNEL, type: 'READY' }, window.location.origin);
    } catch (e) {}
  }

  window.addEventListener('message', event => {
    try {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const message = event.data;
      if (!message || message.channel !== CHANNEL) return;

      if (!isExtensionValid()) return;

      if (message.type === 'PING') {
        notifyReady();
        return;
      }

      if (message.type !== 'API_REQUEST' || !message.requestId) return;

      chrome.runtime.sendMessage({
        type: 'STONEGY_API_REQUEST',
        endpointPath: message.endpointPath,
        options: message.options
      }, response => {
        try {
          const runtimeError = chrome?.runtime?.lastError;
          window.postMessage({
            channel: CHANNEL,
            type: 'API_RESPONSE',
            requestId: message.requestId,
            response: runtimeError
              ? {
                  ok: false,
                  status: 0,
                  data: { success: false, message: runtimeError.message }
                }
              : response
          }, window.location.origin);
        } catch (err) {}
      });
    } catch (err) {
      // Contexto antigo após chrome://extensions -> Recarregar: não propaga o erro.
      try {
        const requestId = event?.data?.requestId;
        if (requestId) window.postMessage({
          channel: CHANNEL,
          type: 'API_RESPONSE',
          requestId,
          response: {
            ok: false,
            status: 0,
            data: { success: false, message: 'Extensão recarregada. Por favor, dê F5 na página do jogo.' }
          }
        }, window.location.origin);
      } catch (e) {}
    }
  });

  try { notifyReady(); } catch (e) {}
})();
