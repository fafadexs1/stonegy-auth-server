@echo off
title Stonegy Tracker Launcher (Google Chrome Native)
chcp 65001 > nul

set EXT_PATH=%~dp0
set TARGET_URL=https://stonegy-online.com/
set CHROME_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe"

echo =========================================================================
echo  ABRINDO GOOGLE CHROME NATIVO DIRETO NO STONEGY ONLINE
echo =========================================================================
echo.
echo Extensao: Stonegy Stats e Event Tracker (Stealth Mode)
echo URL:      %TARGET_URL%
echo.

if exist %CHROME_PATH% (
    start "" %CHROME_PATH% --disable-blink-features=AutomationControlled --load-extension="%EXT_PATH%" --auto-open-devtools-for-tabs "%TARGET_URL%"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --disable-blink-features=AutomationControlled --load-extension="%EXT_PATH%" --auto-open-devtools-for-tabs "%TARGET_URL%"
) else (
    start chrome --disable-blink-features=AutomationControlled --load-extension="%EXT_PATH%" --auto-open-devtools-for-tabs "%TARGET_URL%"
)

exit
